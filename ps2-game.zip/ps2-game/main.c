// "Dodge & Collect" - game PS2 homebrew
// Gerak: analog kiri / D-pad. Kumpulkan koin KUNING (+10), hindari balok MERAH.
// Nyawa 3. Kena balok = -1 nyawa. Game over: tekan START untuk main lagi.
#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <stdio.h>
#include <stdlib.h>
#include <libpad.h>
#include <gsKit.h>
#include <dmaKit.h>

#define RGB(r, g, b) GS_SETREG_RGBAQ(r, g, b, 0x80, 0x00)
#define MAXO 14

static char padBuf[256] __attribute__((aligned(64)));

typedef struct { float x, y, vy; int type; int on; } Obj; // type 0=musuh, 1=koin
static Obj objs[MAXO];

static void init_pad(void)
{
    SifInitRpc(0);
    SifLoadModule("rom0:SIO2MAN", 0, NULL);
    SifLoadModule("rom0:PADMAN", 0, NULL);
    padInit(0);
    padPortOpen(0, 0, padBuf);
    int state;
    do {
        state = padGetState(0, 0);
    } while (state != PAD_STATE_STABLE && state != PAD_STATE_FINDCTP1);
    padSetMainMode(0, 0, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);
}

static float frand(float a, float b)
{
    return a + (b - a) * (rand() % 1000) / 1000.0f;
}

static void rect(GSGLOBAL *gs, float x, float y, float w, float h, u64 c)
{
    gsKit_prim_sprite(gs, x, y, x + w, y + h, 1, c);
}

// Angka 7-segmen (tanpa font)
static void draw_digit(GSGLOBAL *gs, int d, float x, float y, float s, u64 c)
{
    static const u8 m[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
    float w = 14 * s, h = 24 * s, t = 3 * s;
    u8 k = m[d];
    if (k & 1)  rect(gs, x, y, w, t, c);                       // a
    if (k & 2)  rect(gs, x + w - t, y, t, h / 2, c);           // b
    if (k & 4)  rect(gs, x + w - t, y + h / 2, t, h / 2, c);   // c
    if (k & 8)  rect(gs, x, y + h - t, w, t, c);               // d
    if (k & 16) rect(gs, x, y + h / 2, t, h / 2, c);           // e
    if (k & 32) rect(gs, x, y, t, h / 2, c);                   // f
    if (k & 64) rect(gs, x, y + h / 2 - t / 2, w, t, c);       // g
}

static float number_width(int v, float s)
{
    char buf[16];
    sprintf(buf, "%d", v);
    int n = 0;
    while (buf[n]) n++;
    return n * 20 * s;
}

static void draw_number(GSGLOBAL *gs, int v, float x, float y, float s, u64 c)
{
    char buf[16];
    sprintf(buf, "%d", v);
    for (int i = 0; buf[i]; i++)
        draw_digit(gs, buf[i] - '0', x + i * 20 * s, y, s, c);
}

int main(void)
{
    GSGLOBAL *gs = gsKit_init_global();
    gs->PSM = GS_PSM_CT24;
    gs->PSMZ = GS_PSMZ_16S;
    gs->ZBuffering = GS_SETTING_OFF;
    gs->DoubleBuffering = GS_SETTING_ON;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
                D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);
    gsKit_init_screen(gs);
    gsKit_mode_switch(gs, GS_ONESHOT);

    init_pad();

    const float W = gs->Width, H = gs->Height;
    const float PS = 32.0f;     // ukuran pemain
    const float SPEED = 6.0f;

    float px = W / 2 - PS / 2, py = H - PS - 30;
    int score = 0, lives = 3, inv = 0, spawn = 30, over = 0;
    unsigned int frames = 0;
    u32 old = 0;
    int seeded = 0;

    while (1) {
        frames++;
        float dx = 0, dy = 0;
        u32 btn = 0;
        struct padButtonStatus b;
        if (padGetState(0, 0) == PAD_STATE_STABLE && padRead(0, 0, &b)) {
            btn = 0xffff ^ b.btns;
            dx = ((int)b.ljoy_h - 128) / 128.0f;
            dy = ((int)b.ljoy_v - 128) / 128.0f;
            if (dx > -0.2f && dx < 0.2f) dx = 0;
            if (dy > -0.2f && dy < 0.2f) dy = 0;
            if (btn & PAD_LEFT)  dx = -1;
            if (btn & PAD_RIGHT) dx = 1;
            if (btn & PAD_UP)    dy = -1;
            if (btn & PAD_DOWN)  dy = 1;
        }
        if (!seeded && btn) { srand(frames); seeded = 1; }

        if (over) {
            if ((btn & PAD_START) && !(old & PAD_START)) {
                over = 0; score = 0; lives = 3; inv = 0; spawn = 30;
                px = W / 2 - PS / 2; py = H - PS - 30;
                for (int i = 0; i < MAXO; i++) objs[i].on = 0;
            }
        } else {
            px += dx * SPEED;
            py += dy * SPEED;
            if (px < 0) px = 0;
            if (py < 0) py = 0;
            if (px > W - PS) px = W - PS;
            if (py > H - PS) py = H - PS;
            if (inv > 0) inv--;

            // spawn
            if (--spawn <= 0) {
                for (int i = 0; i < MAXO; i++) {
                    if (!objs[i].on) {
                        float sp = 2.0f + score / 120.0f;
                        if (sp > 7.0f) sp = 7.0f;
                        objs[i].on = 1;
                        objs[i].type = (rand() % 100 < 30) ? 1 : 0;
                        objs[i].x = frand(0, W - 28);
                        objs[i].y = -28;
                        objs[i].vy = frand(sp, sp + 2.0f);
                        break;
                    }
                }
                spawn = 40 - score / 15;
                if (spawn < 12) spawn = 12;
            }

            // update + tabrakan
            for (int i = 0; i < MAXO; i++) {
                if (!objs[i].on) continue;
                objs[i].y += objs[i].vy;
                if (objs[i].y > H) { objs[i].on = 0; continue; }
                float os = objs[i].type ? 20.0f : 28.0f;
                if (px < objs[i].x + os && px + PS > objs[i].x &&
                    py < objs[i].y + os && py + PS > objs[i].y) {
                    if (objs[i].type) {
                        score += 10;
                        objs[i].on = 0;
                    } else if (inv == 0) {
                        lives--;
                        inv = 90;
                        objs[i].on = 0;
                        if (lives <= 0) over = 1;
                    }
                }
            }
        }
        old = btn;

        // ---- gambar ----
        gsKit_clear(gs, GS_SETREG_RGBAQ(0x10, 0x10, 0x30, 0x00, 0x00));

        for (int i = 0; i < MAXO; i++) {
            if (!objs[i].on) continue;
            if (objs[i].type) rect(gs, objs[i].x, objs[i].y, 20, 20, RGB(0xFF, 0xD0, 0x20));
            else              rect(gs, objs[i].x, objs[i].y, 28, 28, RGB(0xE0, 0x30, 0x30));
        }

        if (!over && !(inv > 0 && (frames / 4) % 2))
            rect(gs, px, py, PS, PS, RGB(0x40, 0xC0, 0xFF));

        // HUD: nyawa (kiri), skor (kanan)
        for (int i = 0; i < lives; i++)
            rect(gs, 20 + i * 26, 20, 18, 18, RGB(0xFF, 0x50, 0x80));
        draw_number(gs, score, W - number_width(score, 1.0f) - 20, 16, 1.0f, RGB(0xFF, 0xFF, 0xFF));

        if (over) {
            rect(gs, W / 2 - 160, H / 2 - 90, 320, 180, RGB(0x30, 0x00, 0x00));
            float sw = number_width(score, 2.5f);
            draw_number(gs, score, W / 2 - sw / 2, H / 2 - 40, 2.5f, RGB(0xFF, 0xFF, 0xFF));
            // kotak hijau berkedip = "tekan START"
            if ((frames / 30) % 2)
                rect(gs, W / 2 - 20, H / 2 + 50, 40, 20, RGB(0x40, 0xFF, 0x60));
        }

        gsKit_queue_exec(gs);
        gsKit_sync_flip(gs);
    }
    return 0;
}
