#!/usr/bin/env python3
"""Pembuat ISO9660 untuk PS2, murni Python (tanpa mkisofs).
Pakai: python3 make_ps2_iso.py [game.elf] [output.iso]
"""
import struct, sys, os

SEC = 2048
ELF_NAME = "SLUS_000.01"

def both32(n): return struct.pack("<I", n) + struct.pack(">I", n)
def both16(n): return struct.pack("<H", n) + struct.pack(">H", n)
def pad(b, n, c=b" "): return b[:n].ljust(n, c)
def sectors(n): return (n + SEC - 1) // SEC

DATE7 = bytes([126, 10, 23, 0, 0, 0, 0])  # 2026-10-23

def dir_record(extent, size, name, is_dir=False):
    nl = len(name)
    ln = 33 + nl + (1 if nl % 2 == 0 else 0)
    r = bytes([ln, 0]) + both32(extent) + both32(size) + DATE7
    r += bytes([2 if is_dir else 0, 0, 0]) + both16(1) + bytes([nl]) + name
    return r.ljust(ln, b"\x00")

def build(elf_data, out):
    cnf = (f"BOOT2 = cdrom0:\\{ELF_NAME};1\r\nVER = 1.00\r\nVMODE = NTSC\r\n").encode()
    files = [(f"{ELF_NAME};1".encode(), elf_data), (b"SYSTEM.CNF;1", cnf)]  # urut abjad

    root_ext, pt_l, pt_m = 20, 18, 19
    nxt = 21
    entries = []
    for name, data in files:
        entries.append((name, nxt, data))
        nxt += max(1, sectors(len(data)))
    total = nxt

    # direktori root
    root = dir_record(root_ext, SEC, b"\x00", True) + dir_record(root_ext, SEC, b"\x01", True)
    for name, ext, data in entries:
        root += dir_record(ext, len(data), name)
    root = root.ljust(SEC, b"\x00")

    # path table
    ptl = struct.pack("<BBIH", 1, 0, root_ext, 1) + b"\x00\x00"
    ptm = struct.pack(">BBIH", 1, 0, root_ext, 1) + b"\x00\x00"

    pvd = bytearray(SEC)
    pvd[0:8] = b"\x01CD001\x01\x00"
    pvd[8:40] = pad(b"PLAYSTATION", 32)
    pvd[40:72] = pad(b"PS2_HOMEBREW", 32)
    pvd[80:88] = both32(total)
    pvd[120:124] = both16(1)
    pvd[124:128] = both16(1)
    pvd[128:132] = both16(SEC)
    pvd[132:140] = both32(len(ptl))
    pvd[140:144] = struct.pack("<I", pt_l)
    pvd[148:152] = struct.pack(">I", pt_m)
    pvd[156:190] = dir_record(root_ext, SEC, b"\x00", True)[:34]
    for off, ln in [(190, 128), (318, 128), (446, 128), (574, 128),
                    (702, 37), (739, 37), (776, 37)]:
        pvd[off:off+ln] = b" " * ln
    d = b"20261023000000" + b"00" + b"\x00"
    unset = b"0" * 16 + b"\x00"
    pvd[813:830] = d; pvd[830:847] = d; pvd[847:864] = unset; pvd[864:881] = d
    pvd[881] = 1

    term = bytearray(SEC); term[0:8] = b"\xffCD001\x01\x00"

    with open(out, "wb") as f:
        f.write(b"\x00" * SEC * 16)
        f.write(pvd); f.write(term)
        f.write(ptl.ljust(SEC, b"\x00")); f.write(ptm.ljust(SEC, b"\x00"))
        f.write(root)
        for _, _, data in entries:
            f.write(data.ljust(max(1, sectors(len(data))) * SEC, b"\x00"))
    print(f"OK: {out} ({os.path.getsize(out)//1024} KB)")

if __name__ == "__main__":
    elf = sys.argv[1] if len(sys.argv) > 1 else None
    out = sys.argv[2] if len(sys.argv) > 2 else "game.iso"
    data = open(elf, "rb").read() if elf else b"PLACEHOLDER - ganti dengan ELF PS2 asli\n"
    build(data, out)
