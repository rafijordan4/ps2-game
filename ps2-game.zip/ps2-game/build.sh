#!/bin/sh
# Jalankan di terminal GitHub Codespaces:  sh build.sh
set -e
echo "[1/3] Mengunduh toolchain PS2DEV (pertama kali agak lama)..."
docker pull ps2dev/ps2dev:latest

echo "[2/3] Kompilasi game.elf..."
docker run --rm -u "$(id -u):$(id -g)" -v "$PWD":/src -w /src \
  ps2dev/ps2dev:latest sh -c "make clean && make"

echo "[3/3] Membuat game.iso..."
python3 make_ps2_iso.py game.elf game.iso
ls -lh game.elf game.iso
echo "Selesai! Unduh game.iso dari panel file Codespaces (klik kanan > Download)."
